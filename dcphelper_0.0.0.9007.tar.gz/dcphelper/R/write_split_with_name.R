#' @param path
#' @param interactive
#' @param interactive_path
#' @param name
#'
#' @return
#' @export
#' @import parallel
#'
#' @examples
write_split_with_name <- function(df, parent, name){
  well <- df$Metadata_well %>% unique()

  write.csv(df, paste0("~/metadata/metadata_", parent, "_", name, "_", well, ".csv"), row.names=FALSE)
}

# Example function that can be used with mtcars

# cyl_write <- function(df){
#   well <- df$cyl %>% unique
#   write.csv(df, paste0("test_", well))
# }
#
# mtcars %>% mutate(cyl = factor(cyl)) %>% split(.$cyl) %>% parallel::mclapply(cyl_write)
