## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- eval = FALSE-------------------------------------------------------
#  R -q -e "library(dcphelper); dcphelper::create_flatfield_metadata(ch_number = 'ch2')"
#  # Be careful with the "" vs. '' quotes.

## ------------------------------------------------------------------------
dcphelper::create_flatfield_metadata_split(ch_number = 'ch2')

