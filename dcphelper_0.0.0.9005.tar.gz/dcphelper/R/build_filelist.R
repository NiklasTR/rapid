#' Title
#'
#' @param path
#'
#' @return
#' @export
#' @import readr
#'
#' @examples
build_filelist <- function(path){
  # path mus be with trailing backslash
  parent <- path %>% str_split(pattern = "/") %>% unlist %>% .[length(.)-1]
  if(file.exists(paste0("~/metadata/dir_content_", parent ,".txt"))){
    print("Found file list")
  } else {
  print("Initiating file list")
  system(paste0("ls ", path, " > ~/metadata/dir_content_", parent ,".txt"))
  }
  print("Reading file list")
  dir_content <- readr::read_csv(paste0("~/metadata/dir_content_", parent, ".txt"),col_names = FALSE) %>%
  magrittr::set_colnames(c("file_name")) %>%
  mutate(file_path = paste(path, file_name, sep = ""))

  return(dir_content)
}
