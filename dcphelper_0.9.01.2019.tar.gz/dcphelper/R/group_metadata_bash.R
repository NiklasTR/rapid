#' Creating a shell script that used the Distributed Cell Profiler script ManualMetadata.py to create groupings
#'
#' @param metadata_split_path
#'
#' @return
#' @export
#'
#' @examples
group_metadata_bash <- function(metadata_split_path, path_base){

  bash_file <- paste0(path_base, "group_metadata_split_path.sh")

  # create shell script to expand groupings
  fileConn<-file(bash_file)

  # These variable are hardcoded
  python_function <- "python ManualMetadata.py "
  metadata_grouping <- "[\'Metadata_parent\',\'Metadata_timepoint\', \'Metadata_well\', \'Metadata_fld\', \'Metadata_channel\']"

  # Create a shell script
  metadata_split_path %>% unlist() %>% unname() %>% paste0(python_function, ., ' \"', metadata_grouping, '\"') %>%
    #adding the bin bash
    c('#!/bin/sh', .) %>%
    writeLines(., fileConn)

  #run system command to make it executable
  system(paste0("chmod +x ", bash_file))

  #writeLines(c("Hello","World"), fileConn)
  close(fileConn)
  print("Now you have to execute the bash file to group metadata")
}
